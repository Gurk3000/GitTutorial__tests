package net.geocomply.qat510;

public class ChangeRulesBoundaries {

}
