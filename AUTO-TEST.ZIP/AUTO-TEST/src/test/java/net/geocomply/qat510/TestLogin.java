package net.geocomply.qat510;


import org.junit.*;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.awt.*;
import java.util.List;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestLogin extends WebDriverSetting {
   // public WebDriver driver;
    WebDriver driver = new ChromeDriver();

    @Test
    public void TestLogin() {
        // add URL of the site to test
        driver.get("");

        // add user login and password
        driver.findElement(By.xpath("//*[@id='username']")).sendKeys("");
        driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("");
        driver.findElement(By.xpath("//*[@id=\"send\"]")).click();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String urlDash = driver.getCurrentUrl();
        Assert.assertTrue(urlDash.equals("https://qat-bo-reports-510.geocomply.net/dashboard"));

        WebElement myDynamicElement = (new WebDriverWait(driver, 10))
                .until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"system-clients\"]/a/div")));
        myDynamicElement.click();

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement drMenu = driver.findElement(By.xpath("//*[@id=\"clients-list\"]"));
        //drMenu.selectByVisibleText("TestClient");
        List<WebElement> options = drMenu.findElements(By.tagName("li"));

        for (WebElement option : options) {
            if (option.getText().equals("TestClient")) {
                option.getText();
                option.click(); // click the desired option
                break;
            }
        }
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        driver.findElement(By.xpath("//*[@id=\"dialog-alert\"]/div/div/div[2]/button[1]")).click();

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

   }

}