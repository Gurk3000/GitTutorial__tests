package net.geocomply.qat510;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriverSetting {


    @Before
    public void setUp(){
        System.out.println("Test start");

    }
    //@After
    //public void closed1(){
     //   System.out.println("Test close");
      //  driver.quit();
   // }
}